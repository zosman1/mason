package sim.field.partitioning;

import java.io.Serializable;
import java.util.Arrays;
import java.util.stream.IntStream;
import sim.util.*;


public abstract class NumberND implements Comparable<NumberND>, Serializable {

	private static final long serialVersionUID = 1L;

	public final int nd;

	public int getNd() {
		return nd;
	}

	public NumberND(final int nd) {
		super();
		this.nd = nd;
	}

	public abstract Object getArray();

	public abstract double[] getArrayInDouble();

	public abstract String toString();

	public abstract NumberND shift(int offset);

	public abstract NumberND shift(int dim, int offset);

	public abstract NumberND shift(int[] offsets);

	public abstract NumberND rshift(int[] offsets);

	public abstract NumberND shift(double offset);

	public abstract NumberND shift(int dim, double offset);

	public abstract NumberND shift(double[] offsets);

	public abstract NumberND rshift(double[] offsets);

	public abstract NumberND reduceDim(int dim);

	public abstract boolean geq(NumberND that);

	public abstract boolean gt(NumberND that);

	public abstract boolean leq(NumberND that);

	public abstract boolean lt(NumberND that);

	public abstract NumberND max(NumberND that);

	public abstract NumberND min(NumberND that);

	public abstract boolean equals(NumberND that);

	// TODO Use NdRectangle
	public abstract NumberND toToroidal(IntHyperRect bound);

	// TODO better design?
	public abstract int[] getOffsetsInt(NumberND that);

	public abstract double[] getOffsetsDouble(NumberND that);

	public double getDistance(final NumberND that, final int l) {
		final double[] a = that.getArrayInDouble();
		final double[] c = this.getArrayInDouble();
		return Math.pow(IntStream.range(0, nd).mapToDouble(i -> Math.pow(Math.abs(a[i] - c[i]), l)).sum(), 1.0 / l);
	}

	protected static boolean equals(final double a, final double b) {
		return Math.abs(a - b) < Math.ulp(1.0);
	}

	// Utility functions for sanity checks
	protected void assertEqualDim(final int d) {
		if (d < 0 || d >= nd)
			throw new IllegalArgumentException(String.format("Illegal dimension %d given to %s", d, this.toString()));
	}

	protected void assertEqualDim(final int[] a) {
		if (nd != a.length)
			throw new IllegalArgumentException(String.format("%s and %s got different dimensions: %d, %d",
					this.toString(), Arrays.toString(a), nd, a.length));
	}

	protected void assertEqualDim(final double[] a) {
		if (nd != a.length)
			throw new IllegalArgumentException(String.format("%s and %s got different dimensions: %d, %d",
					this.toString(), Arrays.toString(a), nd, a.length));
	}

	protected void assertEqualDim(final NumberND p) {
		if (nd != p.getNd())
			throw new IllegalArgumentException(String.format("%s and %s got different dimensions: %d, %d",
					this.toString(), p.toString(), nd, p.getNd()));
	}

	
}
