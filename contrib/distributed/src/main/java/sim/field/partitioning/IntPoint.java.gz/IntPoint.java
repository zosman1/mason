package sim.field.partitioning;

import java.util.Arrays;
import java.util.stream.IntStream;
import sim.util.*;

public class Int2D extends NumberND {
	private static final long serialVersionUID = 1L;

	public final int[] c;

	public Int2D(final int c[]) {
		super(c.length);
		this.c = Arrays.copyOf(c, nd);
	}

	public Int2D(final int x, final int y) {
		super(2);
		c = new int[] { x, y };
	}

	public Int2D(final int x, final int y, final int z) {
		super(3);
		c = new int[] { x, y, z };
	}

	// Make a copy of array so that Int2D can remain immutable
	public int[] getArray() {
		return Arrays.copyOf(c, nd);
	}

	public double[] getArrayInDouble() {
		return Arrays.stream(c).mapToDouble(x -> x).toArray();
	}

	// TODO Move into NdRectangle
	public int getRectArea(final Int2D that) {
		assertEqualDim(that);
		return nd == 0 ? 0 : Math.abs(Arrays.stream(getOffset(that)).reduce(1, (x, y) -> x * y));
	}

	public Int2D shift(final int dim, final int offset) {
		assertEqualDim(dim);

		final int[] a = getArray();
		a[dim] += offset;

		return new Int2D(a);
	}

	public Int2D shift(final int offset) {
		return new Int2D(IntStream.range(0, nd).map(i -> c[i] + offset).toArray());
	}

	public Int2D shift(final int[] offsets) {
		assertEqualDim(offsets);
		return new Int2D(IntStream.range(0, nd).map(i -> c[i] + offsets[i]).toArray());
	}

	public Int2D rshift(final int[] offsets) {
		assertEqualDim(offsets);
		return new Int2D(IntStream.range(0, nd).map(i -> c[i] - offsets[i]).toArray());
	}

	// TODO make these return Double2D
	public NumberND shift(final double offset) {
		throw new IllegalArgumentException("Int2D cannot be shifted with double offsets");
	}

	public NumberND shift(final int dim, final double offset) {
		throw new IllegalArgumentException("Int2D cannot be shifted with double offsets");
	}

	public NumberND shift(final double[] offsets) {
		throw new IllegalArgumentException("Int2D cannot be shifted with double offsets");
	}

	public NumberND rshift(final double[] offsets) {
		throw new IllegalArgumentException("Int2D cannot be shifted with double offsets");
	}

	// TODO remove
	public int[] getOffset(final Int2D that) {
		return getOffsetsInt(that);
	}

	// Get the distances in each dimension between self and the given point
	public int[] getOffsetsInt(final NumberND that) {
		assertEqualDim(that);

		if (!(that instanceof Int2D))
			throw new IllegalArgumentException("Cannot get int offsets between Int2D and "
					+ that.getClass().getSimpleName());

		final int[] array = (int[]) that.getArray();
		return IntStream.range(0, nd).map(i -> c[i] - array[i]).toArray();
	}

	public double[] getOffsetsDouble(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] array = (int[]) that.getArray();
			return IntStream.range(0, nd).mapToDouble(i -> c[i] - array[i]).toArray();
		} else if (that instanceof Double2D) {
			final double[] array = (double[]) that.getArray();
			return IntStream.range(0, nd).mapToDouble(i -> c[i] - array[i]).toArray();
		} else
			throw new IllegalArgumentException("Cannot get double offsets between Int2D and "
					+ that.getClass().getSimpleName());
	}

	// Reduce dimension by removing the value at the dimth dimension
	public Int2D reduceDim(final int dim) {
		assertEqualDim(dim);

		final int[] newc = Arrays.copyOf(c, nd - 1);
		for (int i = dim; i < nd - 1; i++)
			newc[i] = c[i + 1];

		return new Int2D(newc);
	}

	public boolean equals(final NumberND that) {
		assertEqualDim(that);

		final Object a = that.getArray();
		if (a instanceof int[])
			return Arrays.equals(c, (int[]) a);
		else if (a instanceof double[]) {
			final double[] d = (double[]) a;
			return IntStream.range(0, nd).allMatch(i -> equals(c[i], d[i]));
		} else
			throw new IllegalArgumentException("Unknown type " + that.getClass().getSimpleName());
	}

	// TODO use NdRectangle
	public Int2D toToroidal(final IntHyperRect bound) {
		final int[] size = bound.getSize(), offsets = new int[nd];

		for (int i = 0; i < nd; i++)
			if (c[i] >= bound.br.c[i])
				offsets[i] = -size[i];
			else if (c[i] < bound.ul.c[i])
				offsets[i] = size[i];

		return shift(offsets);
	}

	// // Increase the dimension by inserting the val into the dimth dimension
	// public Int2D increaseDim(int dim, int val) {
	// if (dim < 0 || dim > nd)
	// throw new IllegalArgumentException("Illegal dimension: " + dim);

	// int[] newc = Arrays.copyOf(c, nd + 1);
	// for(int i = dim; i < nd; i++)
	// newc[i + 1] = c[i];
	// newc[dim] = val;

	// return new Int2D(newc);
	// }

	// Sort the points by their components
	@Override
	public int compareTo(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			for (int i = 0; i < nd; i++) {
				if (c[i] == b[i])
					continue;
				return c[i] - b[i];
			}
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			for (int i = 0; i < nd; i++) {
				if (equals(c[i], b[i]))
					continue;
				return c[i] - b[i] > 0 ? 1 : -1;
			}
		} else
			throw new IllegalArgumentException("Cannot compare Int2D with "
					+ that.getClass().getSimpleName());

		return 0;
	}

	public boolean geq(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] >= b[i]);
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] > b[i] || equals(c[i], b[i]));
		} else
			throw new IllegalArgumentException("Cannot compare Int2D with "
					+ that.getClass().getSimpleName());
	}

	public boolean gt(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] > b[i]);
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] > b[i] && !equals(c[i], b[i]));
		} else
			throw new IllegalArgumentException("Cannot compare Int2D with "
					+ that.getClass().getSimpleName());
	}

	public boolean leq(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] <= b[i]);
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] < b[i] || equals(c[i], b[i]));
		} else
			throw new IllegalArgumentException("Cannot compare Int2D with "
					+ that.getClass().getSimpleName());
	}

	public boolean lt(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] < b[i]);
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return IntStream.range(0, nd).allMatch(i -> c[i] < b[i] && !equals(c[i], b[i]));
		} else
			throw new IllegalArgumentException("Cannot compare Int2D with "
					+ that.getClass().getSimpleName());
	}

	public NumberND max(final NumberND that) {
		assertEqualDim(that);

		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return new Int2D(IntStream.range(0, nd).map(i -> Math.max(c[i], b[i])).toArray());
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return new Double2D(IntStream.range(0, nd).mapToDouble(i -> Math.max(c[i], b[i])).toArray());
		} else
			throw new IllegalArgumentException("Cannot get max of Int2D and "
					+ that.getClass().getSimpleName());
	}

	public NumberND min(final NumberND that) {
		if (that instanceof Int2D) {
			final int[] b = (int[]) that.getArray();
			return new Int2D(IntStream.range(0, nd).map(i -> Math.min(c[i], b[i])).toArray());
		} else if (that instanceof Double2D) {
			final double[] b = (double[]) that.getArray();
			return new Double2D(IntStream.range(0, nd).mapToDouble(i -> Math.min(c[i], b[i])).toArray());
		} else
			throw new IllegalArgumentException("Cannot get min of Int2D and "
					+ that.getClass().getSimpleName());
	}

	public String toString() {
		return Arrays.toString(c);
	}

	public static void main(final String[] args) {
		final Int2D pa = new Int2D(new int[] { 1, 1 });
		final Int2D pb = new Int2D(new int[] { 4, 4 });
		final IntHyperRect r = new IntHyperRect(0, pa, pb);

		final Int2D p1 = new Int2D(new int[] { 4, 4 });
		final Int2D p2 = new Int2D(new int[] { 4, 5 });
		final Int2D p3 = new Int2D(new int[] { 5, 4 });
		final Int2D p4 = new Int2D(new int[] { 1, 1 });
		final Int2D p5 = new Int2D(new int[] { 2, 3 });
		final Int2D p6 = new Int2D(new int[] { 1, 0 });
		final Int2D p7 = new Int2D(new int[] { -1, 0 });

		for (final Int2D p : new Int2D[] { p1, p2, p3, p4, p5, p6, p7 })
			System.out.println("toToroidal " + p.toToroidal(r));
	}
}
