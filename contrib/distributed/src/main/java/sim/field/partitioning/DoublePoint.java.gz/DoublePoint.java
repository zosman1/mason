package sim.field.partitioning;

import java.util.Arrays;
import java.util.stream.IntStream;
import sim.util.*;

public class Double2D extends NumberND {
	private static final long serialVersionUID = 1L;

	public final double[] c;

	public Double2D(final double c[]) {
		super(c.length);
		this.c = Arrays.copyOf(c, nd);
	}

	public Double2D(final double x, final double y) {
		super(2);
		c = new double[] { x, y };
	}

	public Double2D(final double x, final double y, final double z) {
		super(3);
		c = new double[] { x, y, z };
	}

	public double[] getArray() {
		return Arrays.copyOf(c, nd);
	}

	public double[] getArrayInDouble() {
		return getArray();
	}

	// TODO Move into NdRectangle
	public double getRectArea(final Double2D that) {
		assertEqualDim(that);
		return nd == 0 ? 0 : Math.abs(Arrays.stream(getOffsetsDouble(that)).reduce(1, (x, y) -> x * y));
	}

	public Double2D shift(final int dim, final double offset) {
		assertEqualDim(dim);

		final double[] newc = Arrays.copyOf(c, nd);
		newc[dim] += offset;

		return new Double2D(newc);
	}

	public Double2D shift(final double offset) {
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> c[i] + offset).toArray());
	}

	public Double2D shift(final double[] offsets) {
		assertEqualDim(offsets);
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> c[i] + offsets[i]).toArray());
	}

	public Double2D rshift(final double[] offsets) {
		assertEqualDim(offsets);
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> c[i] - offsets[i]).toArray());
	}

	public Double2D shift(final int dim, final int offset) {
		return shift(dim, (double) offset);
	}

	public Double2D shift(final int offset) {
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> c[i] + offset).toArray());
	}

	public Double2D shift(final int[] offsets) {
		return shift(Arrays.stream(offsets).mapToDouble(x -> x).toArray());
	}

	public Double2D rshift(final int[] offsets) {
		return rshift(Arrays.stream(offsets).mapToDouble(x -> x).toArray());
	}

	// Get the distances in each dimension between self and the given point
	public int[] getOffsetsInt(final NumberND that) {
		throw new IllegalArgumentException("Cannot get int offsets between Double2D and "
				+ that.getClass().getSimpleName());
	}

	public double[] getOffsetsDouble(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return IntStream.range(0, nd).mapToDouble(i -> c[i] - a[i]).toArray();
	}

	// Reduce dimension by removing the value at the dimth dimension
	public Double2D reduceDim(final int dim) {
		assertEqualDim(dim);

		final double[] newc = Arrays.copyOf(c, nd - 1);
		for (int i = dim; i < nd - 1; i++)
			newc[i] = c[i + 1];

		return new Double2D(newc);
	}

	public boolean equals(final NumberND that) {
		assertEqualDim(that);

		final Object a = that.getArray();
		if (a instanceof double[])
			return Arrays.equals(c, (double[]) a);
		else if (a instanceof int[]) {
			final int[] d = (int[]) a;
			return IntStream.range(0, nd).allMatch(i -> equals(c[i], d[i]));
		} else
			throw new IllegalArgumentException("Unknown type " + that.getClass().getSimpleName());
	}

	// TODO use NdRectangle
	public Double2D toToroidal(final IntHyperRect bound) {
		final int[] size = bound.getSize(), offsets = new int[nd];

		for (int i = 0; i < nd; i++)
			if (c[i] >= bound.br.c[i])
				offsets[i] = -size[i];
			else if (c[i] < bound.ul.c[i])
				offsets[i] = size[i];

		return shift(offsets);
	}

	// Sort the points by their components
	@Override
	public int compareTo(final NumberND that) {
		final double[] a = that.getArrayInDouble();

		for (int i = 0; i < nd; i++) {
			if (equals(c[i], a[i]))
				continue;
			return c[i] - a[i] > 0 ? 1 : -1;
		}

		return 0;
	}

	public boolean geq(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return IntStream.range(0, nd).allMatch(i -> c[i] > a[i] || equals(c[i], a[i]));
	}

	public boolean gt(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return IntStream.range(0, nd).allMatch(i -> c[i] > a[i] && !equals(c[i], a[i]));
	}

	public boolean leq(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return IntStream.range(0, nd).allMatch(i -> c[i] < a[i] || equals(c[i], a[i]));
	}

	public boolean lt(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return IntStream.range(0, nd).allMatch(i -> c[i] < a[i] && !equals(c[i], a[i]));
	}

	public NumberND max(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> Math.max(c[i], a[i])).toArray());
	}

	public NumberND min(final NumberND that) {
		assertEqualDim(that);
		final double[] a = that.getArrayInDouble();
		return new Double2D(IntStream.range(0, nd).mapToDouble(i -> Math.min(c[i], a[i])).toArray());
	}

	public String toString() {
		return Arrays.toString(c);
	}

	public static void main(final String[] args) {
		final Int2D pa = new Int2D(new int[] { 1, 1 });
		final Int2D pb = new Int2D(new int[] { 4, 4 });
		final IntHyperRect r = new IntHyperRect(0, pa, pb);

		final Double2D p1 = new Double2D(new double[] { 4, 4 });
		final Double2D p2 = new Double2D(new double[] { 4, 5 });
		final Double2D p3 = new Double2D(new double[] { 5, 4 });
		final Double2D p4 = new Double2D(new double[] { 1, 1 });
		final Double2D p5 = new Double2D(new double[] { 2, 3 });
		final Double2D p6 = new Double2D(new double[] { 1, 0 });
		final Double2D p7 = new Double2D(new double[] { -1, 0 });

		for (final Double2D p : new Double2D[] { p1, p2, p3, p4, p5, p6, p7 })
			System.out.println("toToroidal " + p.toToroidal(r));
	}
}
